import 'package:flutter/material.dart';

import 'customer_management.dart';
import '../services/data_services.dart';
import 'invoice_management.dart';
import 'product_management.dart';
import 'invoice_list.dart';
import 'login.dart';


// Dashboard Screen
class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  final List<Widget> _screens = [
    DashboardHome(),
    CustomerManagement(),
    ProductManagement(),
    InvoiceManagement(),
    InvoiceList(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoice Management System'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            labelType: NavigationRailLabelType.all,
            destinations: const [
              NavigationRailDestination(
                icon: Icon(Icons.dashboard),
                selectedIcon: Icon(Icons.dashboard),
                label: Text('Dashboard'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.people),
                selectedIcon: Icon(Icons.people),
                label: Text('Customers'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.inventory),
                selectedIcon: Icon(Icons.inventory),
                label: Text('Products'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.receipt),
                selectedIcon: Icon(Icons.receipt),
                label: Text('New Invoice'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.list),
                selectedIcon: Icon(Icons.list),
                label: Text('Invoices'),
              ),
            ],
          ),
          const VerticalDivider(thickness: 1, width: 1),
          Expanded(child: _screens[_selectedIndex]),
        ],
      ),
    );
  }
}

// Dashboard Home
class DashboardHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double totalRevenue =
    DataService.invoices.fold(0.0, (sum, invoice) => sum + invoice.total);

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Dashboard Overview',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _buildStatCard('Total Customers',
                  DataService.customers.length.toString(), Colors.blue),
              const SizedBox(width: 16),
              _buildStatCard('Total Products',
                  DataService.products.length.toString(), Colors.green),
              const SizedBox(width: 16),
              _buildStatCard('Total Invoices',
                  DataService.invoices.length.toString(), Colors.orange),
              const SizedBox(width: 16),
              _buildStatCard('Total Revenue',
                  '\$${totalRevenue.toStringAsFixed(2)}', Colors.purple),
            ],
          ),
          const SizedBox(height: 30),
          const Text(
            'Recent Invoices',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: DataService.invoices.isEmpty
                ? const Center(child: Text('No invoices yet'))
                : ListView.builder(
              itemCount: DataService.invoices.take(5).length,
              itemBuilder: (context, index) {
                final invoice = DataService.invoices[index];
                return Card(
                  child: ListTile(
                    title: Text('Invoice #${invoice.id}'),
                    subtitle: Text(
                        '${invoice.customer.name} - ${invoice.date.toString().split(' ')[0]}'),
                    trailing:
                    Text('\$${invoice.total.toStringAsFixed(2)}'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color) {
    return Expanded(
      child: Card(
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: TextStyle(fontSize: 16, color: Colors.grey[600])),
              const SizedBox(height: 8),
              Text(value,
                  style: TextStyle(
                      fontSize: 32, fontWeight: FontWeight.bold, color: color)),
            ],
          ),
        ),
      ),
    );
  }
}