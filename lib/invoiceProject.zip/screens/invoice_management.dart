import 'package:flutter/material.dart';

import '../models/customer.dart';
import '../models/invoice.dart';
import '../models/invoice_item.dart';
import '../models/product.dart';
import '../services/data_services.dart';

// Invoice Management
class InvoiceManagement extends StatefulWidget {
  @override
  _InvoiceManagementState createState() => _InvoiceManagementState();
}

class _InvoiceManagementState extends State<InvoiceManagement> {
  Customer? selectedCustomer;
  List<InvoiceItem> invoiceItems = [];
  final notesController = TextEditingController();
  double taxRate = 0.1;

  void _showAddItemDialog() {
    Product? selectedProduct;
    final quantityController = TextEditingController(text: '1');
    final discountController = TextEditingController(text: '0');

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Add Item'),
          content: SizedBox(
            width: 400,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<Product>(
                  value: selectedProduct,
                  decoration: const InputDecoration(labelText: 'Product'),
                  items: DataService.products.map((product) {
                    return DropdownMenuItem(
                      value: product,
                      child: Text('${product.name} - ${product.price}'),
                    );
                  }).toList(),
                  onChanged: (product) {
                    setState(() {
                      selectedProduct = product;
                    });
                  },
                ),
                TextField(
                  controller: quantityController,
                  decoration: const InputDecoration(labelText: 'Quantity'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: discountController,
                  decoration: const InputDecoration(labelText: 'Discount'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (selectedProduct != null) {
                  invoiceItems.add(InvoiceItem(
                    product: selectedProduct!,
                    quantity: int.parse(quantityController.text),
                    discount: double.parse(discountController.text),
                  ));
                  this.setState(() {});
                  Navigator.pop(context);
                }
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }

  void _createInvoice() {
    if (selectedCustomer != null && invoiceItems.isNotEmpty) {
      final invoice = Invoice(
        id: DataService.generateId(),
        customer: selectedCustomer!,
        items: List.from(invoiceItems),
        date: DateTime.now(),
        notes: notesController.text.isNotEmpty ? notesController.text : null,
        taxRate: taxRate,
      );
      DataService.invoices.add(invoice);
      setState(() {
        selectedCustomer = null;
        invoiceItems.clear();
        notesController.clear();
        taxRate = 0.1;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invoice created successfully!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    double subtotal = invoiceItems.fold(0.0, (sum, item) => sum + item.total);
    double tax = subtotal * taxRate;
    double total = subtotal + tax;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Create New Invoice',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: DropdownButtonFormField<Customer>(
                  value: selectedCustomer,
                  decoration: const InputDecoration(
                    labelText: 'Select Customer',
                    border: OutlineInputBorder(),
                  ),
                  items: DataService.customers.map((customer) {
                    return DropdownMenuItem(
                      value: customer,
                      child: Text(customer.name),
                    );
                  }).toList(),
                  onChanged: (customer) {
                    setState(() {
                      selectedCustomer = customer;
                    });
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Tax Rate (%)',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      taxRate = double.tryParse(value) ?? 0.1;
                      taxRate = taxRate / 100; // Convert percentage to decimal
                    });
                  },
                  controller:
                  TextEditingController(text: (taxRate * 100).toString()),
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton(
                onPressed: _showAddItemDialog,
                child: const Text('Add Item'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: notesController,
            decoration: const InputDecoration(
              labelText: 'Notes (Optional)',
              border: OutlineInputBorder(),
            ),
            maxLines: 2,
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Card(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Invoice Items',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('Subtotal: ${subtotal.toStringAsFixed(2)}'),
                            Text('Tax: ${tax.toStringAsFixed(2)}'),
                            Text('Total: ${total.toStringAsFixed(2)}',
                                style: const TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: invoiceItems.length,
                      itemBuilder: (context, index) {
                        final item = invoiceItems[index];
                        return ListTile(
                          title: Text(item.product.name),
                          subtitle: Text(
                              'Qty: ${item.quantity}, Discount: ${item.discount.toStringAsFixed(2)}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(item.total.toStringAsFixed(2)),
                              IconButton(
                                icon: const Icon(Icons.delete),
                                onPressed: () {
                                  setState(() {
                                    invoiceItems.removeAt(index);
                                  });
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: ElevatedButton(
                      onPressed:
                      (selectedCustomer != null && invoiceItems.isNotEmpty)
                          ? _createInvoice
                          : null,
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: const Text('Create Invoice'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}