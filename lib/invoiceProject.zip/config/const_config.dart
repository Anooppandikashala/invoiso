// Company Information
class CompanyInfo {
  static const String name = "Your Company Name";
  static const String address = "123 Business Street\nCity, State 12345";
  static const String phone = "(555) 123-4567";
  static const String email = "info@yourcompany.com";
  static const String website = "www.yourcompany.com";
}